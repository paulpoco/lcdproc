The LCDproc source code documentation                            {#mainpage}
=====================================

This is the LCDproc source code documentation. It is generated from comments
in the source code files.

Visit the LCDproc homepage at http://www.lcdproc.org/.
