#ifndef HD_PIFACECAD_H
#define HD_PIFACECAD_H

#include "lcd.h"		/* for Driver */

/* initialise this particular driver */
int hd_init_pifacecad(Driver *drvthis);

#endif
