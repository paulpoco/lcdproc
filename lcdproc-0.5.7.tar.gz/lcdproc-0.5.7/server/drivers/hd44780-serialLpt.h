#ifndef HD_SERIALLPT_H
#define HD_SERIALLPT_H

#include "lcd.h"					  /* for Driver */

// initialise this particular driver
int hd_init_serialLpt(Driver *drvthis);

#endif
